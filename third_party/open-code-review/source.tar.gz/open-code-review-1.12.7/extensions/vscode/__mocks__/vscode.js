// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 alibaba/open-code-review Contributors

module.exports = {
  env: { language: 'en' },
  Uri: { file: (p) => ({ fsPath: p, scheme: 'file' }), joinPath: (...args) => args.join('/') },
  workspace: { workspaceFolders: [{ uri: { fsPath: '/mock' } }], openTextDocument: () => Promise.resolve({ lineCount: 10, lineAt: () => ({ text: '' }) }) },
  window: { showErrorMessage: () => {}, showWarningMessage: () => Promise.resolve(undefined), createOutputChannel: () => ({ appendLine: () => {}, dispose: () => {} }), createWebviewPanel: () => ({ webview: { html: '', onDidReceiveMessage: () => ({ dispose: () => {} }), asWebviewUri: (u) => u }, onDidDispose: () => ({ dispose: () => {} }), reveal: () => {}, dispose: () => {} }) },
  commands: { registerCommand: () => ({ dispose: () => {} }), executeCommand: () => Promise.resolve() },
  extensions: { getExtension: () => null },
  Disposable: { from: (...ds) => ({ dispose: () => ds.forEach((d) => d.dispose()) }) },
  CommentMode: { Preview: 1 },
  CommentThreadCollapsibleState: { Expanded: 0 },
  MarkdownString: function (v) { this.value = v; this.isTrusted = false; },
  Range: function (a, b, c, d) { this.start = { line: a, character: b }; this.end = { line: c, character: d }; },
  WorkspaceEdit: function () { this.replace = () => {}; this.delete = () => {}; },
  ThemeIcon: function () {},
  ViewColumn: { One: 1 },
  EventEmitter: function () { this.event = () => {}; this.fire = () => {}; },
  CommentController: function () { this.createCommentThread = () => ({ canReply: false, label: '', collapsibleState: 0, contextValue: '', comments: [], dispose: () => {} }); },
  WebviewViewProvider: function () {},
};